'''Aim of this client code is to do the testing and getting result of tag predictions '''
import requests
from flask import request
import json
from tag_db import tagDb

# in this function throught parameter we are getting discriptions, also from request.post function we are getting values of tag
#and tagDb function we are storing values in db
def client(testing):
    url = "http://127.0.0.1:5000/"
    r = requests.post(url, data = {'testing' : testing})
    res = json.loads(r.text)
    testing_result=res[1]
    print(testing,testing_result)
    tagDb().tag_db(testing,testing_result)

#entering discriptions via testing variable 
testing='ready to work at night shift, python developer for international shift'
client(testing)
