
"""
this programme load the dataset from drive clean , 
process them.It labels them in Independent and Dependent variables ,
encode them and then train .After training them it saves the model using 
joblib
"""
import pandas as pd
import pandas as pd
import numpy as np
import csv 
import warnings
import pickle
import time
import re
import nltk
from nltk.tokenize import ToktokTokenizer
from nltk.stem.wordnet import WordNetLemmatizer
from nltk.corpus import stopwords
from string import punctuation
from sklearn.svm import SVC
from sklearn.metrics import classification_report
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.linear_model import SGDClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.multiclass import OneVsRestClassifier
from sklearn.svm import LinearSVC
from sklearn.model_selection import train_test_split
import joblib
nltk.download('stopwords')
nltk.download('wordnet')
stop_word = stopwords.words('english')
stop = stopwords.words('english')
from flask import Flask,request, jsonify
from flask import app
warnings.filterwarnings("ignore")


def data_loading():
    """ 
    function to load dataset from drive.
    Parameters : none
    returns : Dataframe 
    
    """

    df = pd.read_csv('data.csv')
    return df

# df = pd.read_csv('data.csv')
# print(df.head())
# function to clean data



def cleanig_data(dataset):
    """
    Function to clean dataset. It removes NAN values , HTML tags 
    and special  characters.
    Parameters : Dataframe [which need to cleaned]
    Returns : Dataframe  [It will be cleaned]
    """


    ''' function to clean text data . It will remove all special char , HTML tags and null values'''
    # removing 'Unnamed: 0' , which is present in dataset bcz of no use.
    dataset.drop(columns=['Unnamed: 0'], inplace=True)
  # removing nan values
    dataset = dataset.dropna()
  # changing all description text into lower form
    dataset['description'] = dataset['description'].str.lower()
  # changing all tags text into lower form
    dataset['tags'] = dataset['tags'].str.lower()

    def cleanHtml(sentence):
        """
        Fuction to clean HTML tags.
        Parameters : text 
        return : cleaned Text        
        """
    #   ''' It cleans all HTML tags '''
        cleanr = re.compile('<.*?>')
        cleantext = re.sub(cleanr, ' ', str(sentence))
        return cleantext
    def cleanPunc(sentence):
        """
        function to clean punctuation.
        Parameters : Text
        Return  : cleaned Text        
        """

        '''function to clean the word of any punctuation or special characters'''
        cleaned = re.sub(r'[?|!|\'|"|#]',r'',sentence)
        cleaned = re.sub(r'[.|,|)|(|\|/]',r' ',cleaned)
        cleaned = cleaned.strip()
        cleaned = cleaned.replace("\n"," ")
        return cleaned
    def keepAlpha(sentence):
        """
        Function to keep alphabetic character.
        Parameter : text
        Return : cleaned text
        """
        ''' only keeping words with no special character'''
        alpha_sent = ""
        for word in sentence.split():
            alpha_word = re.sub('[^a-z A-Z]+', ' ', word)
            alpha_sent += alpha_word
            alpha_sent += " "
        alpha_sent = alpha_sent.strip()
        return alpha_sent
  
    token=ToktokTokenizer()
    lemma=WordNetLemmatizer()

    def lemitizeWords(text):
        ''' function to apply lemmatizer on text'''
        words=token.tokenize(text)
        listLemma=[]
        for w in words:
            x=lemma.lemmatize(w, pos="v")
            listLemma.append(x)
        return ' '.join(map(str, listLemma))
  # applying all defined fuction on dataset columns
    dataset['description'] = dataset['description'].apply(cleanHtml)
    dataset['description'] = dataset['description'].apply(cleanPunc)
    dataset['description'] = dataset['description'].apply(keepAlpha)  
    dataset['description'] = dataset['description'].apply(lambda x: ' '.join([word for word in x.split() if word not in (stop)]))
    dataset['description'] = dataset['description'].apply(lambda x: lemitizeWords(x))
  # returning cleaned dataset
    return dataset


# Tag Processing
# split tags in space
def tag_processing(dataset):
    """"
    Function to Split the tags and make a new column
    (new_tags) which contain splitted tags .
    Parameters : Dataframe [cleaned dataset]
    
    returns : Dataframe [ with a new column ]
    """
    dataset['new_tags'] = dataset["tags"].apply(lambda x: x.split())
    all_tags = [item for sublist in dataset['new_tags'].values for item in sublist]
    cleaned_data = dataset.copy()
    return cleaned_data



# train - test Split
# Defining X and y

def X_and_y(dataset):
    """
    Function to define X (independent feature) and 
    y (dependent feature).
    Parameters : Dataframe [Dataset obtained from tag processing]
    Return [X - description] and [y - tags]
    
    """
    X = dataset['description']
    y = dataset['new_tags']
    return X,y


# encoding MultiLabelBinarizer for dependent lables
# https://scikit-learn.org/stable/modules/generated/sklearn.preprocessing.MultiLabelBinarizer.html
def y_encoding(y):
    """
    Function to encoding dependent feature (tags or y)
    using MultiLabelBinarizer and finds list of classes formed.
    Parameter : y (tags)
    Return : [encoded y] and [list of classes]
    
    """
    mulitlabel_binarizer = MultiLabelBinarizer()
    y_bin = mulitlabel_binarizer.fit_transform(y)
    classes = mulitlabel_binarizer.classes_
    return y_bin,classes

# encoding independent labels or descriptions
# https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.TfidfVectorizer.html
def X_encoding(X):
    """
    Function to encode dependent feature (X or description)
    using TfidfVectorizer .
    Parameter : X or Description
    Return : encoded X and vectorizer
    
    """
    vectorizer = TfidfVectorizer(analyzer = 'word',
                                       min_df=0.0,
                                       max_df = 1.0,
                                       strip_accents = None,
                                       encoding = 'utf-8', 
                                       preprocessor=None,
                                       max_features=1000)
    multilabel_x_data = vectorizer.fit_transform(X)
    return multilabel_x_data , vectorizer


def classification_fun(X,y):
    """
    Function to train model using OneVsRestClassifier technique and logistic regression.
    Parameters : 
      arg1 - X (description)
      arg2 - y (tags)
    Return : classifier [Trined model]
    
    """
    classifier = OneVsRestClassifier(SGDClassifier(loss='log', alpha=0.00001, penalty='l1'))
    classifier.fit(X,y)
    return classifier
   
# app=Flask(__name__)
# @app.route('/')
def fun():
    """
    It is a main function which is calling 
    every function defined in this file in needed order.
    It will dump the model and X-encoding method using joblib.
    Parameters : None
    
    return : None
    """

        
    df = data_loading()
    data_result = cleanig_data(df)
    cleaned_data = tag_processing(data_result)
    X ,y = X_and_y(cleaned_data)
    # print('yes')
    y_bin,classes=y_encoding(y)
    multilabel_x_data , vectorizer=X_encoding(X)
    classifier=classification_fun(multilabel_x_data,y_bin)
    joblib.dump(classifier , 'model.pkl')
    joblib.dump(vectorizer , 'vectorizer.pkl') 
    # print(classes)


fun()


