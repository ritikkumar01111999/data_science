"""
It loads the trained model and and predict the result. 
"""
from flask import Flask, request, jsonify
import joblib
#this function is loading PKL file and predicing the values
def model(testing):
  vect = joblib.load('vectorizer.pkl')
  # saving classifier as model
  model = joblib.load('model.pkl')
  v = vect.transform([testing])
  p = model.predict(v)
  testing_result=print_class(p[0])
  return testing_result

app=Flask(__name__)
@app.route('/',methods = ['GET','POST'])
def main():
  testing=request.form.get('testing')
  testing_result=model(testing)
  return jsonify(testing , testing_result)

if __name__ == '__main__':
    app.run()
